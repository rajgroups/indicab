<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->yieldPushContent('meta_tag'); ?>
    <?php echo $__env->make('layouts.web.dependency.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="home-page bg-one">

    
    <div class="main-wrapper">
        <!-- Top Header-->
        <?php echo $__env->make('layouts.web.partition.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__env->startSection('content'); ?>
            <!-- start Page-content -->
            <!-- end main content-->
            <?php echo $__env->yieldSection(); ?>
        
        <?php echo $__env->make('layouts.web.partition.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <!-- JAVASCRIPT -->
    <?php echo $__env->make('layouts.web.dependency.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>

<?php /**PATH C:\wamp64\www\indicab\resources\views/layouts/web/app.blade.php ENDPATH**/ ?>