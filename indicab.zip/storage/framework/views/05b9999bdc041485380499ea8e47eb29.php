<link rel="shortcut icon" href="<?php echo e(asset('resource/web/assets/img/user/indicab.png')); ?>" type="image/x-icon">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/plugins/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/css/animate.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/plugins/feather/feather.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/plugins/aos/aos.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('resource/web/assets/css/style.css')); ?>">
<?php /**PATH C:\wamp64\www\indicab\resources\views/layouts/web/dependency/css.blade.php ENDPATH**/ ?>