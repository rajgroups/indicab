<header class="header" style="position: static">
    <?php echo $__env->make('layouts.web.partition.top_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
       <nav class="navbar navbar-expand-lg header-nav p-0">
          <div class="navbar-header">
             <a id="mobile_btn" href="javascript:void(0);">
             <span class="bar-icon">
             <span></span>
             <span></span>
             <span></span>
             </span>
             </a>
             <a href="/" class="navbar-brand logo">
             <img src="<?php echo e(asset('resource/web/assets/img/logo.jpg')); ?>" class="img-fluid" alt="Logo">
             </a>
          </div>
          <div class="main-menu-wrapper">
             <div class="menu-header">
                <a href="index.html" class="menu-logo">
                <img src="<?php echo e(asset('resource/web/assets/img/logo.jpg')); ?>" class="img-fluid" alt="Logo">
                </a>
                <a id="menu_close" class="menu-close" href="javascript:void(0);">
                <i class="fas fa-times"></i>
                </a>
             </div>
             <ul class="main-nav">
                <li class="active has-submenu">
                   <a href="index.html">Home <i class="fas fa-chevron-down"></i></a>
                   <ul class="submenu">
                      
                      
                      <li><a href="/all_services" target="_blank">All Services</a></li>
                      <li><a href="/tempo_service" target="_blank">Tempo Service</a></li>
                     <li><a href="/packersandmovers">Packers and Movers</a></li>
                     <li> <a href="/cab" target="_blank">Cab Service</a></li>

                   </ul>
                </li>
                
                  
                <li>
                  <a href="/indicab-packers-movers" target="_blank">About</a>
               </li>
               <li>
                  <a href="/indicab-packers-movers" target="_blank">Service</a>
               </li>
               <li>
                  <a href="/indicab-packers-movers" target="_blank">Contact us</a>
               </li>
                <li>
                    <a href="/indicab-packers-movers" target="_blank">Admin</a>
                 </li>
             </ul>
          </div>
          <ul class="nav header-navbar-rht reg-head">
             <li><a href="register.html" class="reg-btn"><img src="<?php echo e(asset('resource/web/assets/img/icon/users.svg')); ?>" class="me-1" alt="img">Register</a></li>
             <li><a href="login.html" class="log-btn"><img src="<?php echo e(asset('resource/web/assets/img/icon/lock.svg')); ?>" class="me-1" alt="img"> Login</a></li>
             <li><a href="post-project.html" class="login-btn"><i class="feather-plus me-1"></i>Post a Project </a></li>
          </ul>
       </nav>
    </div>
 </header>
<?php /**PATH C:\wamp64\www\indicab\resources\views/layouts/web/partition/header.blade.php ENDPATH**/ ?>