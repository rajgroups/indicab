<?php $__env->startSection('content'); ?>
    <div class="nk-content ">
        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-sm">
                        <div class="nk-block-between g-3">
                            <div class="nk-block-head-content">
                                <h3 class="nk-block-title page-title">Home /
                                    <strong class="text-primary small">service/
                                        <strong class="text-primary small">list/
                                        </strong>
                                </h3>
                                <div class="nk-block-des text-soft">
                                    <ul class="list-inline">
                                        <!-- Show Authenticated User ID -->
                                        <li>User ID: <span class="text-base"><?php echo e(Auth::guard('admin')->user()->id); ?></span></li>

                                        <!-- Show Authenticated User Created Date -->
                                        <li>Created Date: <span class="text-base"><?php echo e(Auth::guard('admin')->user()->created_at->format('d M, Y h:i A')); ?></span></li>

                                        <!-- Example Last Login (Optional) -->
                                        <!-- Assuming you are tracking the last login in your database -->
                                        <li>Last Login: <span class="text-base"><?php echo e(Auth::guard('admin')->user()->last_login ? Auth::guard('admin')->user()->last_login->format('d M, Y h:i A') : 'N/A'); ?></span></li>
                                    </ul>
                                </div>
                            </div>

                            <div class="nk-block-head-content">
                                <a href="<?php echo e(route('admin.service.create')); ?>"
                                    class="btn btn-outline-light bg-white d-none d-sm-inline-flex">
                                    <em class="icon ni ni-plus"></em>
                                    <span>Create</span></a><a href="<?php echo e(route('admin.service.create')); ?>"
                                    class="btn btn-icon btn-outline-light bg-white d-inline-flex d-sm-none"><em
                                        class="icon ni ni-plus"></em></a>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <?php if(session('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('success')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>

                            <?php if(session('error')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <?php echo e(session('error')); ?>

                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>

                            <!-- Display validation errors -->
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            <?php endif; ?>
                            <div id="DataTables_Table_2_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">

                                <table class="datatable-init-export nowrap table dataTable no-footer dtr-inline"
                                    data-export-title="Export" id="DataTables_Table_2"
                                    aria-describedby="DataTables_Table_2_info">
                                    <thead>
                                        <tr role="row">
                                            <th class="sorting_disabled" rowspan="1" colspan="1"
                                                style="width: 40.0469px;">SL.</th>
                                            <th class="sorting" tabindex="0" aria-controls="supplierList" rowspan="1"
                                                colspan="1" style="width: 162.609px;">Name</th>
                                            <th class="sorting_disabled" rowspan="1" colspan="1"
                                                style="width: 101.891px;">Status</th>
                                            <th width="50px;" class="sorting" tabindex="0" aria-controls="supplierList"
                                                rowspan="1" colspan="1" style="width: 50px;">Action
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="odd">
                                            <td><?php echo e($service->id); ?></td>
                                            <td><?php echo e($service->name); ?></td>
                                            <td>
                                                <?php if($service->status == 'active'): ?>
                                                <span class="badge bg-success">Active</span>
                                                <?php elseif($service->status == 'inactive'): ?>
                                                <span class="badge bg-danger">Inactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="d-flex">
                                                    
                                                    <a href="<?php echo e(route('admin.service.edit',$service->id)); ?>"><i class="fa fa-pencil p-2"></i></a>
                                                   <!-- Delete Button with Confirmation Alert -->
                                                    <form action="<?php echo e(route('admin.service.destroy', $service->id)); ?>" method="POST" onsubmit="return confirmDelete()">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">
                                                            <i class="fa fa-trash p-0 m-0"></i>
                                                        </button>
                                                    </form>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    function confirmDelete() {
        return confirm('Are you sure you want to delete this category?');
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\indicab\resources\views/admin/service/list.blade.php ENDPATH**/ ?>