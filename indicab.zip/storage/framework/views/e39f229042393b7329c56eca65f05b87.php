
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="nk-content-inner">
        <div class="nk-content-body mt-5">
            <div class="row" style=" margin-top: 79px; ">
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                            <h4 class="mb-sm-0 font-size-18"><?php echo e(__('messages.Change_Password')); ?></h4>
                            <div class="page-title-right mb-4">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Job list</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if(Session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>

                                <strong><?php echo e(Session('error')); ?></strong>
                            </div>
                        <?php endif; ?>
                        <?php if(Session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>

                                <strong><?php echo e(Session('success')); ?></strong>
                            </div>
                        <?php endif; ?>
                        <form class="needs-validation" method="POST" novalidate="" action="<?php echo e(route('admin.password.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="mb-3">
                                        <label class="form-label"
                                            for="validationCustom01"><?php echo e(__('messages.old_password')); ?></label>
                                        <input type="password" name="current_password" id="current_password" placeholder="*********" class="form-control" required="">
                                        <div class="valid-feedback"> Looks good! </div>
                                        <?php if($errors->has('old_password')): ?>
                                            <div class="invalid-feedback"> <?php echo e($errors->first('old_password')); ?> </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label"
                                            for="validationCustom02"><?php echo e(__('messages.new_password')); ?></label>
                                        <input type="password" class="form-control" id="new_password" placeholder="*********" name="new_password" required="">
                                        <div class="valid-feedback"> Looks good! </div>
                                        <?php if($errors->has('new_password')): ?>
                                            <div class="invalid-feedback"> <?php echo e($errors->first('new_password_confirmation')); ?> </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label" for="validationCustom02"><?php echo e(__('messages.confirm_password')); ?></label>
                                        <input type="password" name="new_password_confirmation" id="new_password_confirmation" placeholder="*********" class="form-control" required="">
                                        <div class="valid-feedback"> Looks good! </div>
                                        <?php if($errors->has('new_password_confirmation')): ?>
                                            <div class="invalid-feedback"> <?php echo e($errors->first('new_password_confirmation')); ?> </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div>
                            <button class="btn btn-primary" type="submit">Submit form</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\indicab\resources\views/admin/settings/password.blade.php ENDPATH**/ ?>