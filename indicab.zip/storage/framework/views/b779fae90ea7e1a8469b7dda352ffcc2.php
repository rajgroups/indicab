<button class="scroll-top scroll-to-target" data-target="html">
    <span class="ti-angle-up"><img src="assets/img/icon/top-icon.svg" class="img-fluid" alt="Img"></span>
</button>
<script src="<?php echo e(asset('resource/web/assets/js/jquery-3.7.1.min.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/js/bootstrap.bundle.min.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/js/owl.carousel.min.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/js/jquery.waypoints.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/js/jquery.counterup.min.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/plugins/aos/aos.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/plugins/select2/js/select2.min.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/js/slick.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/assets/js/script.js')); ?>" type="5372f0a0a0f0009bace4b712-text/javascript"></script>
<script src="<?php echo e(asset('resource/web/cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js')); ?>" data-cf-settings="5372f0a0a0f0009bace4b712-|49" defer></script>
<?php /**PATH /home/agroselv/indicab.net/resources/views/layouts/web/dependency/js.blade.php ENDPATH**/ ?>