<div id="global-loader">
    <div class="whirly-loader"> </div>
    <div class="loader-img">
       <img src="{{ asset('resource/web/assets/img/load-icon.svg')}}" class="img-fluid" alt="Img">
    </div>
</div>
