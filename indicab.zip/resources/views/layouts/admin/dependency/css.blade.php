    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="{{ asset('resource/admin/images/favicon.png')}}">
    <!-- StyleSheets  -->
    <link rel="stylesheet" href=" {{ asset('resource/admin/assets/css/dashlite.css') }}">
    <link id="skin-default" rel="stylesheet" href="{{asset('resource/admin/assets/css/theme.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
