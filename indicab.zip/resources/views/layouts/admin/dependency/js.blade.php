    <!-- JavaScript -->
    <script src="{{asset('resource/admin/assets/js/bundle.js')}}"></script>
    <script src="{{asset('resource/admin/assets/js/scripts.js')}}"></script>
    <script src="{{asset('resource/admin/assets/js/charts/gd-default.js')}}"></script>

    <!-- JavaScript -->
    <script src="{{asset('resource/admin/assets/js/libs/datatable-btns.js?ver=3.2.3')}}"></script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
