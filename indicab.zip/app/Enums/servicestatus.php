<?php

namespace App\Enums;

enum servicestatus: string
{
    case ACTIVE = 'active';
    case INACTIVE = 'inactive';
}